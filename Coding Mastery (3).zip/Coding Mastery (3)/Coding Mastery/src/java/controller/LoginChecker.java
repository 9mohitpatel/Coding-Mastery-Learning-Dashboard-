package controller;

import DAO.UserDAO;
import model.User;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class LoginChecker extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        UserDAO dao = new UserDAO();
        User user = dao.loginUser(email, password, role);

        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            if (role.equals("admin")) {
                response.sendRedirect("admin.jsp");
            } else {
                response.sendRedirect("index.html");
            }
        } else {
            response.getWriter().println("Login Failed! Invalid credentials.");
        }
    }
}
