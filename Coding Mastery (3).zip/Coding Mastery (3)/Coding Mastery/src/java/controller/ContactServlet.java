package controller;

import db.DBConnector;        // Your existing DB helper
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 * Handles POST /contact  – inserts name, email, subject, message into contact_messages
 */
@WebServlet("/contact")          //  <== URL you’ll POST the form to
public class ContactServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // 1.  Read form fields (UTF-8 to avoid garbled text)
        req.setCharacterEncoding("UTF-8");
        String name    = req.getParameter("name");
        String email   = req.getParameter("email");
        String subject = req.getParameter("subject");
        String message = req.getParameter("message");


        // 3.  Insert into DB
        try (Connection con = DBConnector.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO contact_messages (name,email,subject,message) VALUES (?,?,?,?)")) {

            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, subject);
            ps.setString(4, message);

            ps.executeUpdate();
            // 4.  Redirect or show thank-you
            resp.sendRedirect("contact_thanks.html");  // or forward to JSP
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                           "Unable to save your message, please try again later.");
        }
    }

    // Optional: block GET requests
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED, "POST only");
    }
}
