package controller;

import db.DBConnector;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class EnrollmentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set response type
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get form data
        String fullName = request.getParameter("name");
        String mobileNumber = request.getParameter("mobile");
        String email = request.getParameter("email");
        String course = request.getParameter("course");
        String paymentMode = request.getParameter("payment");

        try {
            // Get DB connection
            Connection conn = DBConnector.getConnection();

            // Prepare SQL statement
            String sql = "INSERT INTO enrollment(name, mobile, email, course, payment) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, fullName);
            ps.setString(2, mobileNumber);
            ps.setString(3, email);
            ps.setString(4, course);
            ps.setString(5, paymentMode);

            // Execute insert
            int status = ps.executeUpdate();

            // Respond to client
           if (status > 0) {
    response.sendRedirect("userDashboard.jsp");   // <— go load dashboard
} else {
    out.println("<h2>Enrollment failed. Please try again.</h2>");
}


            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<h2>Error occurred: " + e.getMessage() + "</h2>");
        }

        out.close();
    }
}
