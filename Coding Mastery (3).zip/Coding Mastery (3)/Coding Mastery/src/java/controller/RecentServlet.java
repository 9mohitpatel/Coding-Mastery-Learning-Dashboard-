package controller;

import DAO.RecentDao;
import model.User;
import model.enroll;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class RecentServlet extends HttpServlet {

    /** GET = show admin dashboard with recent enrollments */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        /* ---------- 1.  Session / auth check ---------- */
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;
        if (user == null) {                     // no user ⇒ bounce to login page
            response.sendRedirect("try.html");  // or login_register.html – your choice
            return;
        }

        /* ---------- 2.  Load recent enrollments ---------- */
        try {
            List<enroll> enrollments = RecentDao.getRecentEnrollments();
            System.out.println("RecentServlet list size = " + enrollments.size());

            request.setAttribute("recentEnrollments", enrollments);

            /* ---------- 3.  Forward to dashboard JSP ---------- */
            RequestDispatcher rd = request.getRequestDispatcher("admin.jsp");
            rd.forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(
                HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                "Error loading recent registrations: " + e.getMessage()
            );
        }
    }

    /** POST simply delegates to GET (e.g., if you later use a form button to refresh) */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Loads 5 most-recent enrollments and shows the admin dashboard";
    }
}
