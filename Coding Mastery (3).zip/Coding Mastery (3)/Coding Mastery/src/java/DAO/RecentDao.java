package DAO;

import db.DBConnector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.enroll;

public class RecentDao {

    /** Returns at most 5 most-recent rows from enrollment table */
    public static List<enroll> getRecentEnrollments() throws Exception {
        List<enroll> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnector.getConnection();
            String sql =
                "SELECT name, email, course, mobile " +
                "FROM   enrollment " +
                "ORDER  BY id DESC " +
                "LIMIT  5";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                enroll e = new enroll();
                e.setName   (rs.getString("name"));
                e.setEmail  (rs.getString("email"));
                e.setCourse (rs.getString("course"));
                e.setMobile (rs.getString("mobile"));
                list.add(e);
            }

            System.out.println("RecentDao rows fetched = " + list.size());
        } finally {
            if (rs  != null) rs.close();
            if (ps  != null) ps.close();
            if (conn!= null) conn.close();
        }

        return list;
    }
}
