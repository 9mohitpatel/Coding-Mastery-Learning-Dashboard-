/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import db.DBConnector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.enroll;

/**
 *
 * @author ASUS
 */
public class enrollDao {
    public boolean saveEnroll(enroll Enroll) throws SQLException
           
    {
        boolean result=false;
        
      try{
          Connection con=DBConnector.getConnection();
          String query="INSERT INTO enrollment(name, mobile, email, course, payment) VALUES (?, ?, ?, ?, ?)";
          PreparedStatement st=con.prepareStatement(query);
          st.setString(1,Enroll.getName());
          st.setString(2, Enroll.getMobile());
          st.setString(3, Enroll.getEmail());
          st.setString(4, Enroll.getCourse());
          st.setString(5, Enroll.getPayment());
             int i = st.executeUpdate();
             if(i>0)
             {
                 result=true;
             }
          
      } 
      catch (Exception ex) {
            ex.printStackTrace();
        }
      return result;
    }
    
}
