package model;

public class enroll {
    private String name;
    private String mobile;
    private String email;
    private String course; 
    private String payment;

    // No-arg constructor — required for some frameworks and for DAO when using setters
    public enroll() {
        // empty constructor - do NOT throw exception here
    }

    // Main constructor with all fields
    public enroll(String name, String mobile, String email, String course, String payment) {
        this.name = name;
        this.mobile = mobile;
        this.email = email;
        this.course = course;
        this.payment = payment;
    }

    // Optional: If you want a constructor with Date (if your DB has date fields),
    // implement it properly or remove it if unused
    // public enroll(String name, String mobile, String email, Date date) { ... }

    // Getters and setters
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getCourse() {
        return course;
    }
    public void setCourse(String course) {
        this.course = course;
    }
    public String getPayment() {
        return payment;
    }
    public void setPayment(String payment) {
        this.payment = payment;
    }
}
